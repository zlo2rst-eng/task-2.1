/**
 * Seminar 2.1 Blockchain primitive
 */

const SHA256 = require('ethereum-cryptography/sha256').sha256;
const utf8ToBytes = require('ethereum-cryptography/utils').utf8ToBytes;


class Block {
    constructor(data){
        this.data = data;      // Here we simplify data, let it be just a simple string
        this.previousHash = null;
    }

    toHash(){
        const hashBytes = utf8ToBytes(this.data + this.previousHash);
        return SHA256(hashBytes);        // a hash as byte array
    }
}


// Сравнение двух хешей (Uint8Array) либо null-значений.
function hashEquals(a, b) {
    if (a === b) return true;            // оба null или одна ссылка
    if (!a || !b) return false;          // один null, другой нет
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
        if (a[i] !== b[i]) return false;
    }
    return true;
}


class Blockchain {
    constructor() {

        this.chain = [
            // TODO 1: генезис-блок — первый блок в цепочке.
            new Block("Genesis"),
        ];
    }

    addBlock(block){
        // TODO 2: записываем в новый блок хеш предыдущего блока цепочки.
        const previousBlock = this.chain[this.chain.length - 1];
        block.previousHash = previousBlock.toHash();
        this.chain.push(block);
    }

    isValid(){
        // TODO 3: у каждого блока (кроме генезиса) previousHash должен совпадать
        // с хешем предыдущего блока. Любое расхождение -> false.
        for (let i = 1; i < this.chain.length; i++) {
            const expected = this.chain[i - 1].toHash();
            if (!hashEquals(this.chain[i].previousHash, expected)) {
                return false;
            }
        }
        return true;
    }
}

module.exports = { Block, Blockchain };
